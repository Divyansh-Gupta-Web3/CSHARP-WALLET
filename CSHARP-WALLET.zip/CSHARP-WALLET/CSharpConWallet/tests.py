"""This module is used define the test cases for the app"""

from django.test import TestCase

# Create your tests here.
